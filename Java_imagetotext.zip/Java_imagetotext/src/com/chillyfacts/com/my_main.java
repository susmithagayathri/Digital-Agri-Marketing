package com.chillyfacts.com;
import java.io.PrintWriter;

import conversionpack.Read_File;
import conversionpack.UI1;
	public class my_main {
		public static void main(String[] args) {
			String tesseract_install_path="F:\\Tesseract-OCR\\tesseract";
			String fileText;
			String output_file="F:";
			String[] command =
		    {
		        "cmd",
		    };
			
		    Process p;
			try {
				p = Runtime.getRuntime().exec(command);
		                PrintWriter stdin = new PrintWriter(p.getOutputStream());
		                stdin.close();
		                p.waitFor();
		                fileText=Read_File.read_a_file(output_file+".txt");
		                new UI1(fileText).setVisible(true);
		                System.out.println(fileText);
		    	} catch (Exception e) {
		 		e.printStackTrace();
			}
		}	
	}	