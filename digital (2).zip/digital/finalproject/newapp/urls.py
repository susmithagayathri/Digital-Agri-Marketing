"""finalproject URL Configuration
The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from newapp import views
from django.conf import settings
from django.conf.urls.static import static

app_name = 'newapp'


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.Home),
    path('action_page/',views.action_page),
    path('about/',views.About),
    path('action_page/',views.action_page),
    path('register/',views.register,name="register"),
    path('action_page/',views.action_page),
    path('login/',views.login ,name="login"),
    path('gallery/',views.gallery),
    path('shop/',views.shop),
    path('shop-detail/',views.shopdetail),
    path('cart/',views.Cart),
    path('checkout/',views.checkout),
    path('my-account/',views.myaccount),
    path('login1/',views.login1,name="login1"),
    path('product/', views.product),
    path('wishlist/',views.wishlist),
    path('action_page/',views.action_page),
    path('contact-us/',views.contactus),
    path('view_user/',views.viewuser),
    path('view_booking/',views.viewbooking),
    path('add_product/',views.addproduct),
    path('view_product/',views.viewproduct),
    path('Aboutproduct/',views.Aboutproduct),
    path('contact-form/',views.contactForm),
    path('index2/',views.index2),
    path('post/',views.post),
    path('home/', views.home,name='home'),
    path('success/', views.success,name='success'),
    path('cart1/',views.product_list, name="product_list"),
    path('<slug:category_slug>/',views.product_list,name="product_list_by_category"),
    path('<int:id>/<slug:slug>/',views.product_detail,name="product_detail"),
]
