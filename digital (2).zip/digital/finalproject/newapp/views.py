from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpRequest
from newapp.forms import Studentform,Productssform
from newapp.models import Students,Productss
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import *
from django.shortcuts import render
import razorpay
from django.views.decorators.csrf import csrf_exempt

from newapp.models import Category
from django.shortcuts import get_object_or_404, render
from .models import Category, Product
from cart.forms import CartAddProductForm








def Home(request):
    return render(request,"index.html")

def About(request):
    return render(request,"about.html")
def login(request):
    return render(request,"login.html")
def register(request):
    return render(request,"register.html")
def Cart(request):
    return render(request,"cart.html")
def checkout(request):
    return render(request,"checkout.html" )
def contactus(request):
    return render(request,"contact-us.html")
def gallery(request):
    return render(request,"gallery.html")
def myaccount(request):
    return render(request,"my-account.html")
def shopdetail(request):
    return render(request,"shop-detail.html")
def shop(request):
    return render(request,"shop.html")
def wishlist(request):
    return render(request,"wishlist.html")
def product(request):
    return render(request,"product.html")
def viewuser(request):
    return render(request,"view_user.html")
def viewbooking(request):
    return render(request,"view_booking.html")
def addproduct(request):
    return render(request,"add_product.html")
def viewproduct(request):
    return render(request,"view_product.html")
def Aboutproduct(request):
    return render(request,"Aboutproduct.html")
def index2(request):
    return render(request,"index2.html")


def action_page(request):
    
    form=Studentform(request.POST)
    if form.is_valid():
        try:
            form.save()
            return HttpResponse("<h1> SUCCESS </h1>")
        except:
            pass
    return HttpResponse("<h1> ERROR </h1>")

def register(request):
    if request.method=="POST":
        firstname=request.POST['firstname']
        middlename=request.POST['middlename']
        lastname=request.POST['lastname']
        gender=request.POST['gender']
        phone=request.POST['phone']
        currentaddres=request.POST['currentaddres']
        email=request.POST['email']
        password=request.POST['password']
         
        form=Students(firstname=firstname,middlename=middlename,lastname=lastname,phone=phone,currentaddres=currentaddres,email=email,password=password,gender=gender)
        form.save()
        messages.success(request,'The new user'+request.POST['firstname']+"is saved")
        return render(request,'login.html')
    else:
        return render(request,'register.html')

def login(request):
    if request.method=="POST":
        email=request.POST['email']
        password=request.POST['password']
        if Students.objects.filter(email=email,password=password).exists():
            isLogged=Students.objects.get(email=email, password=password)
            return render(request,'index.html',{'firstname':isLogged.firstname})
        else:
            return render(request,'login.html',{'msg':'Login Failed'})
    else:
        return render(request,'login.html')

def login1(request):
    if request.method=="POST":
        username=request.POST['username']
        password=request.POST['password']
        if Seller.objects.filter(username=username,password=password).exists():
            isLogged=Seller.objects.get(username=username, password=password)
            return render(request,'index.html',{'username':isLogged.username})
        else:
            return render(request,'product.html',{'msg':'Login Failed'})
    return render(request,'index.html')

#def contact_us(request):
    #if request.method=="POST":
        #username=request.POST['username']
        #password=request.POST['password']
        #if Seller.objects.filter(username=username,password=password).exists():
            #isLogged=Seller.objects.get(username=username, password=password)
           # return render(request,'index.html',{'username':isLogged.username})
       # else:
            #return render(request,'product.html',{'msg':'Login Failed'})
   # return render(request,'index.html')
    
def View_user(request):
    if not request.user.is_authenticated:
        return redirect('view_user')
    pro = Profile.objects.all()
    d = {'user':pro}
    return render(request,'view_user.html',d)

def post(request):
    if request.method == "POST":
        form = Productssform(request.POST, request.FILES)
        # pimage=request.POST('pimage')
        # pimage=form.cleaned_data['pimage']
        productname = request.POST['pname']
        productImage = request.FILES['img']
        ProductPrice = request.POST['price']
        Description = request.POST['desc']
        category= request.POST['category']
        # if form.is_valid():
        product=Productss(productName=productname,productimage=productImage,productprice=ProductPrice,Description=Description,category=category)
        product.save()
        # obj=form.instance
        obj=Productss.objects.all()
        return render(request, "view_product.html",{"obj" : obj})
        # return redirect('/view_product/')
    else:
        form=Productssform()
    img=Productss()
    return render(request, "add_product.html", {"img": img, "form": form})

def viewproduct(request):
    obj=Productss.objects.all()
    return render(request, "view_product.html",{"obj" : obj})

def contactForm(request):
    if request.method=="POST":
        return redirect('/')
    return render(request,'pay.html',{'msg':"Message send successfully"})

def checkout(request):
    if request.method=="POST":
        return redirect('/')
    return render(request,'pay.html',{'msg':"Message send successfully"})

def home(request):
    if request.method == "POST":
        name = request.POST.get('name')
        amount = 5000
        
  
        client = razorpay.Client(auth=("rzp_test_EOUl3FQUj5l4Jj", "TQ72BbepLgqz4IFImlZKxMmp"))
        payment = client.order.create({'amount': amount, 'currency': 'INR','payment_capture': '1'})

    return render(request, 'pay.html')

@csrf_exempt
def success(request):
    return render(request, "success.html")



def product_list(request, category_slug = None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available = True)
    if category_slug:
        category = get_object_or_404(Category,slug=category_slug)
        products = products.filter(category=category)
    return render(request, 'newapp/product/list.html', {'category':category,'categories':categories,'products':products})

def product_detail(request, id, slug):
    product=get_object_or_404(Product,id=id,slug=slug,available=True)
    cart_product_form = CartAddProductForm()
    return render(request, "newapp/product/detail.html", {'product':product, 'cart_product_form':cart_product_form})