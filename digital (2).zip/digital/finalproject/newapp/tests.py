from newapp import TestCase

# Create your tests here.
