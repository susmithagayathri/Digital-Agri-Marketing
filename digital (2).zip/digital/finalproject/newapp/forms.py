from django import forms
from newapp.models import Productss, Students
from django.forms import Textarea

class Studentform (forms.ModelForm):
    class Meta:
        model=Students
        fields="__all__"

CATEGORY_CHOICES = [('fruits', 'Fruits'),
                        ('Vegetables', 'vegetables'),
                        ('Nuts','nuts'),
                        ]

class Productssform(forms.ModelForm):
    class Meta:
        model = Productss
        widgets={'despt': Textarea(attrs={'cols':80,'rows':20}),}
        category=forms.CharField(label='Category Type ?',widget=forms.RadioSelect(choices=CATEGORY_CHOICES))

      #  time=forms.IntegerField(attrs={'required': False})
        pimage=forms.ImageField()
        fields="__all__"