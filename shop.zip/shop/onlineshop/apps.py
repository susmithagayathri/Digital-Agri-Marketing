from django.apps import AppConfig


class OnlineshopConfig(AppConfig):
    name = 'onlineshop'
